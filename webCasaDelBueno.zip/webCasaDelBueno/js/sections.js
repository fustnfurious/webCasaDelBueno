$(document).ready(sections);

function sections(){
  var current=1;

  function switchReview(current, next){
    var nextReview = "<img id=\""+next+"review\" src=\"media/reviews/"+next+"review.png\" style=\"opacity: 0;\">";
    $(".slideshowReviewsHolder").append(nextReview);
    $("#"+current+"review").animate({
      opacity: 0
    }, 1000);
    $("#"+next+"review").animate({
      opacity: 1
    }, 1000);
    setTimeout(function(){
      $("#"+current+"review").remove();
    }, 1000);
  }

  var intReview = setInterval(function(){
    next = (current+1);
    if(next==6){
      next=1;
    }
    switchReview(current, next);
    current=next;
  }, 4000);

  $(".arrowRightHolder").click(function(){
    clearInterval(intReview);
    next = (current+1);
    if(next==6){
      next=1;
    }
    switchReview(current, next);
    current=next;
  });
  $(".arrowLeftHolder").click(function(){
    clearInterval(intReview);
    next = (current-1);
    if(next==0){
      next=5;
    }
    switchReview(current, next);
    current=next;
  });
}
